import os
import psycopg2
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Path
from fastapi.responses import JSONResponse

# Load environment variables from .env file
load_dotenv()

# --- Database Connection Details ---
DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")
DB_NAME = os.getenv("DB_NAME")
DB_SCHEMA = os.getenv("DB_SCHEMA") # This will be 'VC_QC' as per your .env file

# --- FastAPI App Initialization ---
app = FastAPI(
    title="Table Schema Generator API",
    description="An API to generate JSON schema from a PostgreSQL table description.",
    version="1.0.0",
)

# --- Helper Function (No changes here) ---
def map_pg_type_to_json(pg_type: str):
    """Maps PostgreSQL data types to JSON schema type definitions."""
    if pg_type in ("integer", "bigint", "smallint"):
        return {"type": "integer"}
    if pg_type in ("numeric", "decimal", "real", "double precision"):
        return {"type": "number"}
    if "character varying" in pg_type or "text" in pg_type:
        return {"type": "string"}
    if "date" == pg_type:
        return {"type": "string", "format": "date"}
    if "timestamp" in pg_type:
        return {"type": "string", "format": "date-time"}
    if "boolean" == pg_type:
        return {"type": "boolean"}
    return {"type": "string"}


# --- API Endpoint with THE FIX ---
@app.get("/schema/{param1}/{param2}/{param3}", tags=["Schema"])
async def get_table_schema(
    param1: str = Path(..., min_length=1, max_length=1, description="First part of the table name (e.g., 'p')."),
    param2: str = Path(..., min_length=1, description="Second part of the table name (e.g., 'allegro')."),
    param3: str = Path(..., min_length=1, description="Third part of the table name (e.g., 'price').")
):
    # 1. Concatenate parameters to form the table name
    table_name = f"vc_qc_{param1}_{param2}_{param3}".lower()

    # --- THE FIX IS HERE ---
    # Use the schema name EXACTLY as it is in the .env file. Do NOT convert to lowercase.
    db_schema_for_query = DB_SCHEMA
    
    print("\n--- INCOMING REQUEST ---")
    print(f"Constructed table name: '{table_name}'")
    print(f"Schema for query: '{db_schema_for_query}'") # This should now print 'VC_QC'

    # 2. Define the SQL query
    query = """
        SELECT column_name, data_type, is_nullable
        FROM information_schema.columns
        WHERE table_schema = %s
        AND table_name = %s
        ORDER BY ordinal_position;
    """

    conn = None
    try:
        # 3. Connect to the PostgreSQL database
        print(f"Attempting to connect to database '{DB_NAME}'...")
        conn = psycopg2.connect(
            dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT
        )
        cursor = conn.cursor()
        print("✅ Connection successful.")

        # 4. Execute the query with the CORRECT schema name
        print(f"Executing query...")
        cursor.execute(query, (db_schema_for_query, table_name))
        
        print(f"Query found {cursor.rowcount} rows.")
        columns_data = cursor.fetchall()

        if not columns_data:
            print("❌ No data found for the given schema and table name.")
            raise HTTPException(
                status_code=404,
                detail=f"Table '{table_name}' not found in schema '{db_schema_for_query}'.",
            )
        
        print("✅ Data fetched successfully. Generating schema...")
        # 5. Convert the database response to JSON Schema format
        properties = {}
        required_fields = []
        for col_name, data_type, is_nullable in columns_data:
            json_type_def = map_pg_type_to_json(data_type)
            if is_nullable.upper() == 'YES':
                properties[col_name] = {"type": [json_type_def["type"], "null"]}
                if "format" in json_type_def:
                    properties[col_name]["format"] = json_type_def["format"]
            else:
                properties[col_name] = json_type_def
                required_fields.append(col_name)

        # 6. Construct the final JSON schema structure
        final_schema = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object", "properties": {"Prices": {"type": "object", "properties": {"Price": {"type": "array", "items": {"type": "object", "properties": properties, "required": sorted(required_fields), "additionalProperties": False}}}, "required": ["Price"], "additionalProperties": False}}, "required": ["Prices"], "additionalProperties": False
        }

        return JSONResponse(content=final_schema)

    except psycopg2.Error as e:
        print(f"❌ DATABASE ERROR: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    finally:
        if conn:
            conn.close()
            print("Connection closed.")