import os
import psycopg2
from fastapi import FastAPI, HTTPException
from dotenv import load_dotenv
from psycopg2.extras import DictCursor
import logging

# Load environment variables from .env file
load_dotenv()

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- FastAPI App Initialization ---
app = FastAPI(
    title="ETRM Trade Data API",
    description="API to serve trade data from the PostgreSQL database.",
    version="1.0.0"
)

# --- Database Connection ---
def get_db_connection():
    """Establishes a connection to the PostgreSQL database."""
    try:
        conn = psycopg2.connect(
            dbname=os.getenv("DB_NAME"),
            user=os.getenv("DB_USER"),
            password=os.getenv("DB_PASS"),
            host=os.getenv("DB_HOST"),
            port=int(os.getenv("DB_PORT", 5432))  # Convert to int and provide default
        )
        logger.info("Database connection established successfully")
        return conn
    except psycopg2.OperationalError as e:
        logger.error(f"Database connection failed: {e}")
        raise HTTPException(status_code=503, detail=f"Database connection failed: {e}")
    except Exception as e:
        logger.error(f"Unexpected error during database connection: {e}")
        raise HTTPException(status_code=503, detail=f"Database connection failed: {e}")

# --- Test Database Connection Endpoint ---
@app.get("/test-db", summary="Test database connection")
def test_database_connection():
    """Test if we can connect to the database and access the tables."""
    try:
        conn = get_db_connection()
        schema = os.getenv("DB_SCHEMA", "VC_QC")
        
        with conn.cursor() as cur:
            # Test if tables exist
            cur.execute("""
                SELECT table_name 
                FROM information_schema.tables 
                WHERE table_schema = %s 
                AND table_name IN ('VC_QC_Trades', 'VC_QC_TradeDataSets')
            """, (schema,))
            
            tables = cur.fetchall()
            
            # Count records in each table
            cur.execute(f'SELECT COUNT(*) FROM "{schema}".VC_QC_TradeDataSets')
            dataset_count = cur.fetchone()[0]
            
            cur.execute(f'SELECT COUNT(*) FROM "{schema}".VC_QC_Trades')
            trade_count = cur.fetchone()[0]
            
        conn.close()
        
        return {
            "status": "success",
            "schema": schema,
            "tables_found": [table[0] for table in tables],
            "dataset_count": dataset_count,
            "trade_count": trade_count
        }
        
    except Exception as e:
        logger.error(f"Database test failed: {e}")
        raise HTTPException(status_code=500, detail=f"Database test failed: {e}")

# --- API Endpoint ---
@app.get("/trades", summary="Fetch all trades with dataset details")
def get_all_trades():
    """
    Retrieves all trades by joining the Trades and TradeDataSets tables.
    This reconstructs the flattened data structure the dashboard expects.
    """
    conn = None
    try:
        conn = get_db_connection()
        schema = os.getenv("DB_SCHEMA", "VC_QC")
        
        query = f"""
            SELECT
                t.TradeID,
                t.Timestamp,
                t.Exchange,
                t.Side,
                t.Quantity,
                t.Price,
                t.Currency,
                t.Trader,
                t.Counterparty,
                t.ClearingAccount,
                t.ExecutionVenue,
                t.InstrumentSymbol        AS "Symbol",
                t.InstrumentProductType   AS "ProductType",
                t.InstrumentExpiry        AS "Expiry",
                d.Source,
                d.Target,
                d.Tag,
                d.CreatedDate
            FROM
                "{schema}".VC_QC_Trades t
            JOIN
                "{schema}".VC_QC_TradeDataSets d ON t.TradeDataSetID = d.TradeDataSetID
            ORDER BY
                t.Timestamp DESC;
        """
        
        logger.info(f"Executing query: {query}")
        
        with conn.cursor(cursor_factory=DictCursor) as cur:
            cur.execute(query)
            results = cur.fetchall()
            trades = [dict(row) for row in results]
            
            logger.info(f"Retrieved {len(trades)} trades")
            return {
                "status": "success",
                "count": len(trades),
                "data": trades
            }
            
    except psycopg2.Error as e:
        logger.error(f"PostgreSQL error: {e}")
        raise HTTPException(status_code=500, detail=f"Database query failed: {e}")
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        raise HTTPException(status_code=500, detail=f"An error occurred while fetching data: {e}")
    finally:
        if conn:
            conn.close()

# --- Get specific trade by ID ---
@app.get("/trades/{trade_id}", summary="Fetch a specific trade by ID")
def get_trade_by_id(trade_id: str):
    """Retrieve a specific trade by its TradeID."""
    conn = None
    try:
        conn = get_db_connection()
        schema = os.getenv("DB_SCHEMA", "VC_QC")
        
        query = f"""
            SELECT
                t.TradeID,
                t.Timestamp,
                t.Exchange,
                t.Side,
                t.Quantity,
                t.Price,
                t.Currency,
                t.Trader,
                t.Counterparty,
                t.ClearingAccount,
                t.ExecutionVenue,
                t.InstrumentSymbol        AS "Symbol",
                t.InstrumentProductType   AS "ProductType",
                t.InstrumentExpiry        AS "Expiry",
                d.Source,
                d.Target,
                d.Tag,
                d.CreatedDate
            FROM
                "{schema}".VC_QC_Trades t
            JOIN
                "{schema}".VC_QC_TradeDataSets d ON t.TradeDataSetID = d.TradeDataSetID
            WHERE
                t.TradeID = %s;
        """
        
        with conn.cursor(cursor_factory=DictCursor) as cur:
            cur.execute(query, (trade_id,))
            result = cur.fetchone()
            
            if result is None:
                raise HTTPException(status_code=404, detail=f"Trade with ID {trade_id} not found")
            
            return {
                "status": "success",
                "data": dict(result)
            }
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching trade {trade_id}: {e}")
        raise HTTPException(status_code=500, detail=f"An error occurred while fetching trade: {e}")
    finally:
        if conn:
            conn.close()

# --- Root Endpoint for Health Check ---
@app.get("/", summary="API Health Check")
def read_root():
    return {
        "status": "ETRM Trade Data API is running",
        "version": "1.0.0",
        "endpoints": {
            "/": "Health check",
            "/test-db": "Test database connection",
            "/trades": "Get all trades",
            "/trades/{trade_id}": "Get specific trade by ID"
        }
    }

# For running with uvicorn
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)