import json
import random
from faker import Faker
from datetime import datetime, timedelta

fake = Faker()

def generate_trade_list(tag):
    """Generates a list of trade dictionaries based on the tag."""
    trade_list = []
    
    if tag == "Allegro_Trades":
        # Generate Futures trades
        symbols = [("ES", 4500, 4800), ("CL", 75, 95), ("NG", 2.5, 4.5), ("GC", 2300, 2400)]
        product_type = "FUT"
        exchanges = ["CME", "NYMEX", "COMEX"]
        traders = [fake.first_name() for _ in range(5)]
        counterparties = [f"Broker{fake.company_suffix()}" for _ in range(4)]
        
        for _ in range(random.randint(50, 100)):
            symbol_info = random.choice(symbols)
            trade = {
                "TradeID": f"FUT-{random.randint(100000, 999999)}",
                "Timestamp": (datetime.now() - timedelta(days=random.randint(0, 7), hours=random.randint(0,23))).isoformat() + "Z",
                "Exchange": random.choice(exchanges),
                "Instrument": {
                    "Symbol": f"{symbol_info[0]}{random.choice(['M','U','Z'])}{str(datetime.now().year)[-1]}",
                    "ProductType": product_type,
                    "Expiry": (datetime.now() + timedelta(days=random.randint(30, 365))).strftime('%Y-%m-%d')
                },
                "Side": random.choice(["Buy", "Sell"]),
                "Quantity": str(random.randint(1, 20)),
                "Price": str(round(random.uniform(symbol_info[1], symbol_info[2]), 2)),
                "Currency": "USD",
                "Trader": random.choice(traders),
                "Counterparty": random.choice(counterparties),
                "ClearingAccount": f"{random.choice(['ABC','XYZ','DEF'])}{random.randint(100,999)}",
                "ExecutionVenue": "CME"
            }
            trade_list.append(trade)
            
    elif tag == "SmartFramework_Trades":
        # Generate Swaps and Physical trades
        swap_symbols = [("HenryHub_NYMEX", 5, 8), ("TTF_Index", 5, 7), ("NBP_Gas", 6, 8)]
        liquid_symbols = [("WTI Crude Oil", 70, 85), ("Brent Crude", 75, 90)]
        gas_symbols = [("LNG - Qatar", 9, 12)]
        traders = ["ClientABC", "UtilityA", "TraderX", "ProducerABC", "OilCoAlpha", "PowerUtilityZ"]
        counterparties = [fake.company() for _ in range(10)]
        
        for _ in range(random.randint(80, 150)):
            trade_type = random.choice(["CommoditySwap", "Liquid", "Gas"])
            symbol_info = None
            if trade_type == "CommoditySwap": symbol_info = random.choice(swap_symbols)
            elif trade_type == "Liquid": symbol_info = random.choice(liquid_symbols)
            else: symbol_info = random.choice(gas_symbols)
            
            trade = {
                "TradeID": f"{'SWAP' if trade_type == 'CommoditySwap' else 'PHYS'}-{random.randint(1000, 9999)}",
                "Timestamp": (datetime.now() - timedelta(days=random.randint(0, 7), hours=random.randint(0,23))).isoformat() + "Z",
                "Exchange": "N/A",
                "Instrument": {
                    "Symbol": symbol_info[0],
                    "ProductType": trade_type,
                    "Expiry": (datetime.now() + timedelta(days=random.randint(30, 365))).strftime('%Y-%m-%d')
                },
                "Side": random.choice(["Buy", "Sell", "N/A"]),
                "Quantity": random.randint(1000, 50000),
                "Price": round(random.uniform(symbol_info[1], symbol_info[2]), 3),
                "Currency": random.choices(["USD", "EUR", "GBP"], weights=[0.8, 0.15, 0.05])[0],
                "Trader": random.choice(traders),
                "Counterparty": random.choice(counterparties),
                "ClearingAccount": "N/A",
                "ExecutionVenue": random.choice(["Cushing, OK", "Rotterdam", "Doha", "N/A"])
            }
            trade_list.append(trade)

    return trade_list

def generate_full_dataset():
    """Builds the final JSON structure."""
    
    trade_datasets = [
        {
            "Source": "Allegro",
            "Target": "RightAngle",
            "Tag": "Allegro_Trades",
            "Trades": {
                "TradeList": generate_trade_list("Allegro_Trades")
            }
        },
        {
            "Source": "Allegro",
            "Target": "RightAngle",
            "Tag": "SmartFramework_Trades",
            "Trades": {
                "TradeList": generate_trade_list("SmartFramework_Trades")
            }
        }
    ]
    
    return {"TradeDataSets": trade_datasets}

if __name__ == "__main__":
    print("Generating dummy business ETRM data...")
    final_data = generate_full_dataset()
    
    file_path = "business_etrm_data.json"
    with open(file_path, 'w') as f:
        json.dump(final_data, f, indent=2)
        
    print(f"✅ Data successfully generated and saved to '{file_path}'")