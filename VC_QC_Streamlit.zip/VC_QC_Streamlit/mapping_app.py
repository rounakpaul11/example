import streamlit as st
import requests
import json
import pandas as pd
import psycopg2
from psycopg2 import sql

# --- Database Configuration ---
# WARNING: In a real app, use Streamlit Secrets or environment variables.
DB_USER = "VC_QC1"
DB_PASS = "Y34!c{sYp2FX"
DB_HOST = "10.50.10.6"
DB_PORT = "5432"
DB_NAME = "VC_QC"
DB_SCHEMA = "VC_QC"

# --- API Configuration ---
API_BASE_URL = "http://127.0.0.1:8000"
PARAM1_OPTIONS = ['p', 'c']
PARAM2_OPTIONS = ['allegro', 'amazon', 'ebay', 'shopify']
PARAM3_OPTIONS = ['price', 'product', 'stock', 'order']


# --- Database Function (No changes) ---
def save_multiple_mappings(pattern_name, source_fields: list, target_fields: list):
    """Inserts multiple mapping records in a single transaction."""
    query = sql.SQL("""
        INSERT INTO {schema}.{table} (patternname, sourcefield, targetfield, createddate)
        VALUES (%s, %s, %s, NOW());
    """).format(
        schema=sql.Identifier(DB_SCHEMA),
        table=sql.Identifier('vc_qc_fieldmappings')
    )
    conn = None
    try:
        conn = psycopg2.connect(dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)
        cursor = conn.cursor()
        for source, target in zip(source_fields, target_fields):
            cursor.execute(query, (pattern_name, source, target))
        conn.commit()
        cursor.close()
        return True, f"Successfully saved {len(source_fields)} mappings!"
    except psycopg2.Error as e:
        if conn: conn.rollback()
        return False, f"Database Error: {e}"
    finally:
        if conn: conn.close()

# --- Utility Functions (No changes) ---
def extract_column_info(schema: dict):
    try:
        properties = schema['properties']['Prices']['properties']['Price']['items']['properties']
        columns = [c for c in properties.keys()]
        return columns
    except (KeyError, IndexError): return None

def display_schema_table(schema_json: dict, header: str):
    st.subheader(header)
    try:
        properties = schema_json['properties']['Prices']['properties']['Price']['items']['properties']
        required_fields = schema_json['properties']['Prices']['properties']['Price']['items']['required']
        column_data = []
        for name, details in properties.items():
            data_type = details.get('type')
            primary_type = [t for t in data_type if t != "null"][0] if isinstance(data_type, list) else data_type
            is_required = name in required_fields
            column_data.append({"Column Name": name, "Data Type": primary_type, "Required": "✅" if is_required else "❌"})
        df = pd.DataFrame(column_data)
        st.dataframe(df, use_container_width=True, hide_index=True)
    except (KeyError, IndexError):
        st.warning("Could not display schema details.")

def fetch_schema(param1, param2, param3):
    url = f"{API_BASE_URL}/schema/{param1}/{param2}/{param3}"
    try:
        st.info(f"🚀 Calling API: `{url}`")
        response = requests.get(url)
        response.raise_for_status()
        st.success("✅ Schema fetched successfully!")
        return response.json()
    except requests.exceptions.RequestException as e:
        st.error(f"❌ Connection or API Error. Details: {e}")
        return None

# --- NEW: Callback Function for the Save Button ---
def handle_save_mappings():
    """
    This function is called when the 'Commit Mappings' button is clicked.
    It handles validation, database insertion, and clearing the inputs for the next run.
    """
    # Read values directly from session state
    pattern_name = st.session_state.get("pattern_name_input", "").strip()
    source_list = st.session_state.get("producer_map_select", [])
    target_list = st.session_state.get("consumer_map_select", [])
    
    # --- Validation Logic ---
    if not pattern_name:
        st.toast("⚠️ Please enter a pattern name.", icon="⚠️")
        return
    if not source_list or not target_list:
        st.toast("⚠️ Please select at least one field from both sides.", icon="⚠️")
        return
    if len(source_list) != len(target_list):
        st.error(f"Selection Mismatch: {len(source_list)} producer fields vs. {len(target_list)} consumer fields. Counts must be identical.")
        return
        
    # --- If validation passes, call the save function ---
    success, message = save_multiple_mappings(pattern_name, source_list, target_list)
    if success:
        st.success(message)
        # It is SAFE to modify session state for other widgets inside a callback.
        # These values will be cleared before the next script rerun.
        st.session_state.producer_map_select = []
        st.session_state.consumer_map_select = []
        st.session_state.pattern_name_input = ""
    else:
        st.error(message)

# --- Streamlit App Layout ---
st.set_page_config(layout="wide", page_title="Schema Mapper")
st.title("↔️ Schema Mapping Screen")

if 'producer_schema' not in st.session_state: st.session_state.producer_schema = None
if 'consumer_schema' not in st.session_state: st.session_state.consumer_schema = None

# Step 1: Fetch Schemas
st.header("1. Fetch Schemas")
col1, col2 = st.columns(2)
with col1:
    st.subheader("🟢 Producer (Source)")
    # ... (code for fetching producer schema is unchanged) ...
    p_param1 = st.selectbox("Param1 (Type)", PARAM1_OPTIONS, key="p_param1")
    p_param2 = st.selectbox("Param2 (System)", PARAM2_OPTIONS, key="p_param2")
    p_param3 = st.selectbox("Param3 (Entity)", PARAM3_OPTIONS, key="p_param3")
    if st.button("Fetch Producer Schema", use_container_width=True):
        st.session_state.producer_schema = fetch_schema(p_param1, p_param2, p_param3)
    if st.session_state.producer_schema:
        display_schema_table(st.session_state.producer_schema, "Producer Columns")

with col2:
    st.subheader("🔵 Consumer (Target)")
    # ... (code for fetching consumer schema is unchanged) ...
    c_param1 = st.selectbox("Param1 (Type)", PARAM1_OPTIONS, key="c_param1", index=1)
    c_param2 = st.selectbox("Param2 (System)", PARAM2_OPTIONS, key="c_param2", index=1)
    c_param3 = st.selectbox("Param3 (Entity)", PARAM3_OPTIONS, key="c_param3")
    if st.button("Fetch Consumer Schema", use_container_width=True):
        st.session_state.consumer_schema = fetch_schema(c_param1, c_param2, c_param3)
    if st.session_state.consumer_schema:
        display_schema_table(st.session_state.consumer_schema, "Consumer Columns")

st.divider()

# Step 2 & 3: Map Fields and Save
if st.session_state.producer_schema and st.session_state.consumer_schema:
    st.header("2. Map Fields")
    st.info("Select fields from both sides. The mapping is based on **order of selection**.")

    map_col1, map_col2 = st.columns(2)
    p_cols = extract_column_info(st.session_state.producer_schema) or []
    c_cols = extract_column_info(st.session_state.consumer_schema) or []

    with map_col1:
        st.multiselect("Select Producer Fields (in order)", options=p_cols, key="producer_map_select")
    with map_col2:
        st.multiselect("Select Consumer Fields (in order)", options=c_cols, key="consumer_map_select")
    
    st.divider()
    st.header("3. Save Mapping Pattern")

    # MODIFIED: The text input now has a key so the callback can access it.
    st.text_input(
        "Enter a name for this mapping pattern",
        placeholder="e.g., Allegro Price to Shopify Price",
        key="pattern_name_input"
    )
    
    # MODIFIED: The button now uses `on_click` to call our function.
    # The `if` statement is no longer needed.
    st.button(
        "Commit Mappings to Database",
        on_click=handle_save_mappings, # This is the magic!
        use_container_width=True,
        type="primary"
    )
else:
    st.info("Fetch both a Producer and Consumer schema to begin mapping.")