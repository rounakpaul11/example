import streamlit as st
import json
from jsonschema import Draft7Validator
import pandas as pd
import psycopg2 # --- NEW ---
from psycopg2.extras import execute_values # --- NEW: More efficient for bulk inserts

# --- NEW: Database Configuration ---
# WARNING: In a real app, use Streamlit Secrets or environment variables.
DB_USER = "VC_QC1"
DB_PASS = "Y34!c{sYp2FX"
DB_HOST = "10.50.10.6"
DB_PORT = "5432"
DB_NAME = "VC_QC"
DB_SCHEMA = "VC_QC"
DB_TABLE = "vc_qc_p_allegro_price"

# --- Page Configuration ---
st.set_page_config(
    page_title="Interactive Rule Validation Engine",
    page_icon="🛠️",
    layout="wide",
)

# --- NEW: Database Insertion Function ---
def insert_price_data(records: list):
    """
    Connects to the PostgreSQL database and performs a bulk insert of price records
    into the specified table using an efficient, single transaction.
    """
    insert_query = f"""
        INSERT INTO "{DB_SCHEMA}".{DB_TABLE} (
            curve_name, price_index, price_type, price_date, delivery_date,
            settle, open, high, low, currency
        ) VALUES %s;
    """
    conn = None
    try:
        data_to_insert = []
        for record in records:
            # This tuple maps JSON keys to the database column order
            row_tuple = (
                record['CurveName'], record['PriceIndex'], record['PriceType'],
                record['PriceDate'], record['DeliveryDate'], record.get('Settle'),
                record.get('Open'), record.get('High'), record.get('Low'),
                record['Currency']
            )
            data_to_insert.append(row_tuple)

        conn = psycopg2.connect(
            dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT
        )
        cursor = conn.cursor()
        execute_values(cursor, insert_query, data_to_insert)
        conn.commit()
        
        return True, f"✅ Success! Inserted {len(data_to_insert)} records into `{DB_TABLE}`."

    except (Exception, psycopg2.Error) as error:
        if conn: conn.rollback()
        return False, f"❌ Database Error: {error}"
    finally:
        if conn:
            cursor.close()
            conn.close()

# --- NEW: Callback for the Insert Button ---
def handle_insert():
    """
    This function is called when the 'Insert Data' button is clicked.
    It reads the data from the main app scope and triggers the insertion.
    """
    if data and 'data' in data and isinstance(data['data'], list):
        with st.spinner(f"Inserting {len(data['data'])} records into the database..."):
            success, message = insert_price_data(data['data'])
            # Display the result from the insertion function
            if success:
                st.success(message)
            else:
                st.error(message)
    else:
        st.warning("Could not find a 'data' array to insert.")

# --- Helper Function to Load JSON Files ---
def load_json(filepath):
    """Loads a JSON file and handles potential errors."""
    try:
        with open(filepath, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        st.error(f"Error: The file '{filepath}' was not found. Please make sure it's in the same directory as the app.")
        return None
    except json.JSONDecodeError:
        st.error(f"Error: The file '{filepath}' is not a valid JSON file. Please check its content.")
        return None

def validate_and_report(data, schema):
    """
    Validates the data against the schema using Draft7Validator to collect all errors.
    Returns a list of formatted error messages.
    """
    validator = Draft7Validator(schema)
    errors = sorted(validator.iter_errors(data), key=lambda e: e.path)
    
    if not errors:
        return []

    error_messages = []
    for error in errors:
        # Create a more readable path to the error location
        path = " -> ".join(map(str, error.path)) if error.path else "Top-level"
        
        # Provide specific details about the error
        if error.validator == "required":
             message = f"**Missing required property**: `{error.message.split("'")[1]}`"
        elif error.validator == "enum":
            message = f"**Invalid value**: `{error.instance}` is not one of {error.validator_value}"
        else:
            message = f"**Validation failed**: {error.message}"

        error_messages.append(f"Error in record at path `{path}`. {message}")
        
    return error_messages


# --- Main Application ---
st.title(" Interactive Rule Validation Engine")
st.markdown("---")

# --- Load Data and Schema ---
data = load_json('data.json')
schema = load_json('schema.json')

if not data or not schema:
    st.stop()

# --- UI Layout ---
st.sidebar.header("Rule Engine Configuration")
st.sidebar.info(
    "This is a conceptual UI. Currently, only the 'Validation Rules' section is functional "
    "for basic JSON Schema checks."
)
with st.sidebar.expander("1. Schema Mapping Rules", expanded=False):
    st.write("Define field renames, merges, or splits.")
    st.text_input("Source Field", "fullName")
    st.text_input("Target Field", "first_name, last_name")
    st.button("Add Mapping Rule", key="map")
with st.sidebar.expander("2. Data Format Conversion", expanded=False):
    st.write("Define format-to-format transformations.")
    st.selectbox("Source Format", ["JSON", "XML", "CSV"], key="src_fmt")
    st.selectbox("Target Format", ["JSON", "SQL", "CSV"], key="tgt_fmt")
    st.button("Add Conversion Rule", key="convert")
with st.sidebar.expander("3. Data Type Transformation", expanded=False):
    st.write("Define type conversions for specific fields.")
    st.text_input("Field Name", "trade_date")
    st.selectbox("From Type", ["String", "Integer", "Date"], key="type_from")
    st.selectbox("To Type", ["Date", "String", "Timestamp"], key="type_to")
    st.button("Add Type Rule", key="type")
with st.sidebar.expander("4. Validation Rules", expanded=True):
    st.success("This section is active!")
    st.write("This section uses the `schema.json` to validate the structure and content of `data.json`.")
    run_validation = st.button("🚀 Run Schema Validation", type="primary")
with st.sidebar.expander("5. Cleansing Rules", expanded=False):
    st.write("Define rules to clean data.")
    st.checkbox("Trim whitespace from all string fields")
    st.checkbox("Standardize units (e.g., 'kg' to 'kilograms')")
    st.button("Add Cleansing Rule", key="clean")
with st.sidebar.expander("6. Business Logic Rules", expanded=False):
    st.write("Apply custom business logic.")
    st.text_area("Rule Definition", "IF product_type == 'FUT' THEN risk_category = 'High'")
    st.button("Add Business Rule", key="biz")

# --- Main Content Area ---
st.subheader("Data and Schema Overview")
col1, col2 = st.columns(2)
with col1:
    with st.expander("View Source Data (`data.json`)", expanded=False): st.json(data)
with col2:
    with st.expander("View Validation Schema (`schema.json`)", expanded=False): st.json(schema)

st.subheader("Source Trade Records")
if 'data' in data and isinstance(data['data'], list):
    df = pd.DataFrame(data['data'])
    st.dataframe(df, use_container_width=True)
else:
    st.warning("Could not find a 'data' array in the source JSON.")

# --- Validation Logic and Results ---
if run_validation:
    st.markdown("---")
    st.subheader("Validation Results")
    with st.spinner("Validating data against schema..."):
        validation_errors = validate_and_report(data, schema)

        if not validation_errors:
            st.toast('Validation Passed!', icon='✅')
            st.success("✅ **Validation Passed!** The `data.json` file perfectly conforms to the `schema.json`.")
            
            # --- NEW: Action Button on Successful Validation ---
            st.markdown("---")
            st.subheader("🚀 Next Step: Load to Database")
            st.info(f"The data is valid and ready to be inserted into the `{DB_TABLE}` table.")
            st.button(
                "Insert Validated Data into Database",
                on_click=handle_insert,
                type="primary",
                use_container_width=True
            )
            
        else:
            error_count = len(validation_errors)
            st.toast(f'Validation Failed: {error_count} errors found.', icon='❌')
            st.error(f"❌ **Validation Failed!** Found {error_count} error(s).")
            for error in validation_errors:
                st.warning(error)