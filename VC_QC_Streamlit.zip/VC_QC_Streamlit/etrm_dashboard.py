import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import requests
from datetime import datetime, timedelta
from streamlit_date_picker import date_range_picker, PickerType
import json # --- NEW CODE START ---: Import for handling JSON file

# --- PAGE CONFIGURATION ---
st.set_page_config(
    page_title="ETRM Business Dashboard",
    page_icon="💼",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- NEW CODE START ---
@st.cache_data
def load_validation_logs(file_path="validation_logs.json"):
    """
    Loads and parses the validation log JSON file.
    Returns a DataFrame of log entries and a summary object.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        log_entries = data.get('validation_log', {}).get('log_entries', [])
        if not log_entries:
            st.warning(f"No log entries found in '{file_path}'.")
            return pd.DataFrame(), None

        df = pd.DataFrame(log_entries)
        df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')

        # Separate the final summary log entry for KPIs
        summary_log = df[df['rule_category'] == 'FINAL']
        # Exclude the summary from the main analysis dataframe
        df = df[df['rule_category'] != 'FINAL']
        
        return df.dropna(subset=['timestamp']), summary_log

    except FileNotFoundError:
        st.error(f"**Error:** The log file '{file_path}' was not found. Please create it in the same directory.")
        return pd.DataFrame(), None
    except json.JSONDecodeError:
        st.error(f"**Error:** The file '{file_path}' is not a valid JSON file.")
        return pd.DataFrame(), None
    except Exception as e:
        st.error(f"An unexpected error occurred while reading the log file: {e}")
        return pd.DataFrame(), None
# --- NEW CODE END ---

@st.cache_data(ttl=600)  # Cache data for 10 minutes
def load_data_from_api(api_url="http://127.0.0.1:8000/trades"):
    """
    Fetches trade data from the FastAPI endpoint, renames columns to match
    the application's expectations, and cleans the data.
    """
    try:
        response = requests.get(api_url, timeout=10)
        response.raise_for_status()
        api_response = response.json()
        
        if api_response.get("status") != "success":
            st.error(f"❌ **API Error!** {api_response.get('detail', 'Unknown error')}")
            return None
            
        trade_data = api_response.get("data", [])
        
        if not trade_data:
            return pd.DataFrame()

        trades_df = pd.DataFrame(trade_data)

        # --- FIX: RENAME COLUMNS FROM API TO MATCH SCRIPT ---
        # This is the key change. It maps the API's lowercase names
        # to the PascalCase names used throughout the rest of the script.
        column_mapping = {
            'tradeid': 'TradeID',
            'timestamp': 'Timestamp',
            'exchange': 'Exchange',
            'side': 'Side',
            'quantity': 'Quantity',
            'price': 'Price',
            'currency': 'Currency',
            'trader': 'Trader',
            'counterparty': 'Counterparty',
            'clearingaccount': 'ClearingAccount',
            'executionvenue': 'ExecutionVenue',
            'tag': 'Tag',
            'createddate': 'CreatedDate'
            # Note: 'Symbol', 'ProductType', 'Expiry' are already capitalized in the API output,
            # so they don't strictly need to be in the map, but it's good practice.
        }
        trades_df.rename(columns=column_mapping, inplace=True)
        # --- END OF FIX ---

        # --- Data Cleaning and Type Conversion (this will now work correctly) ---
        if 'Timestamp' in trades_df.columns:
            trades_df['Timestamp'] = pd.to_datetime(trades_df['Timestamp'], utc=True, errors='coerce').dt.tz_localize(None)
        
        if 'Expiry' in trades_df.columns:
            trades_df['Expiry'] = pd.to_datetime(trades_df['Expiry'], errors='coerce')
        
        numeric_columns = ['Quantity', 'Price']
        for col in numeric_columns:
            if col in trades_df.columns:
                trades_df[col] = pd.to_numeric(trades_df[col], errors='coerce')
        
        # This line was causing the error, but will now work
        trades_df = trades_df.dropna(subset=['Quantity', 'Price']) 
        
        string_columns = ['Side', 'Exchange', 'Currency', 'Trader', 'Counterparty', 
                         'Tag', 'Symbol', 'ProductType']
        for col in string_columns:
            if col in trades_df.columns:
                trades_df[col] = trades_df[col].fillna('N/A')
        
        return trades_df.sort_values(by="Timestamp", ascending=False)
        
    except requests.exceptions.ConnectionError:
        st.error(f"❌ **API Connection Error!** Could not connect to the API at `{api_url}`. Please ensure the API server is running.")
        st.code("uvicorn api:app --reload --host 0.0.0.0 --port 8000")
        st.info("💡 **Tip:** Make sure your FastAPI server is running and accessible.")
        return None
    except requests.exceptions.Timeout:
        st.error(f"⏱️ **API Timeout!** The API at `{api_url}` took too long to respond.")
        return None
    except requests.exceptions.RequestException as e:
        st.error(f"❌ **API Request Error!** {str(e)}")
        return None
    # This specific error will no longer happen, but the general catch-all is good to keep
    except Exception as e:
        st.error(f"❌ **Data Processing Error:** {str(e)}")
        st.info("This might be due to unexpected data format from the API.")
        # For debugging, you can uncomment the line below to see the full error in your console
        # print(trades_df.columns) 
        return None

# --- API HEALTH CHECK ---
def check_api_health(api_base_url="http://127.0.0.1:8000"):
    """Check if the API is running and accessible."""
    try:
        response = requests.get(f"{api_base_url}/", timeout=5)
        return response.status_code == 200
    except:
        return False

# --- MAIN DATA LOADING WITH BETTER ERROR HANDLING ---
st.sidebar.title("🌐 API Status")

# Check API health first
api_healthy = check_api_health()
if api_healthy:
    st.sidebar.success("✅ API Connected")
else:
    st.sidebar.error("❌ API Disconnected")
    st.error("🚨 **Cannot connect to the API!** Please ensure your FastAPI server is running.")
    st.code("uvicorn api:app --reload --host 0.0.0.0 --port 8000", language="bash")
    st.stop()

# Load the data
with st.spinner("🔄 Loading trade data from API..."):
    trades_df = load_data_from_api()

# --- Graceful handling if data loading fails ---
if trades_df is None:
    st.stop() # Stop execution if the API failed
    
if trades_df.empty:
    st.warning("⚠️ **No trade data found!** The API returned an empty dataset.")
    st.info("This could mean:")
    st.markdown("""
    - No trades exist in the database
    - Database connection issues
    - Permissions problems
    - Empty tables
    """)
    st.stop()

# Show data loading success
st.sidebar.info(f"📊 Loaded {len(trades_df):,} trades")

# --- SESSION STATE & SIDEBAR (Updated with custom date picker) ---
if 'active_view' not in st.session_state:
    st.session_state.active_view = 'home'

def set_view(view_name):
    st.session_state.active_view = view_name

st.sidebar.title("📊 Dashboard Controls")
st.sidebar.info("Filter the trade data across all views.")

# Check if we have timestamp data
if 'Timestamp' not in trades_df.columns or trades_df['Timestamp'].isna().all():
    st.error("❌ **Missing Timestamp Data!** Cannot create time-based filters.")
    st.stop()

min_ts, max_ts = trades_df['Timestamp'].min(), trades_df['Timestamp'].max()
default_start = max_ts - timedelta(hours=24)
default_end = max_ts

st.sidebar.markdown("### ⏰ Time Granularity")
time_granularity = st.sidebar.radio(
    "Select time precision:", options=["Hourly", "Daily"], index=0, horizontal=True
)

if time_granularity == "Hourly":
    refresh_buttons = [
        {'button_name': '⏰ Last 6 Hours', 'refresh_value': timedelta(hours=6)},
        {'button_name': '⏰ Last 12 Hours', 'refresh_value': timedelta(hours=12)},
        {'button_name': '⏰ Last 24 Hours', 'refresh_value': timedelta(hours=24)},
        {'button_name': '⏰ Last 3 Days', 'refresh_value': timedelta(days=3)}
    ]
    picker_type = PickerType.time
    st.sidebar.markdown("### ⏰ Date & Time Range Selection")
else:
    refresh_buttons = [
        {'button_name': '📅 Last 7 Days', 'refresh_value': timedelta(days=7)},
        {'button_name': '📅 Last 30 Days', 'refresh_value': timedelta(days=30)},
        {'button_name': '📅 Last 90 Days', 'refresh_value': timedelta(days=90)},
        {'button_name': '📅 Year to Date', 'refresh_value': timedelta(days=(datetime.now() - datetime(datetime.now().year, 1, 1)).days)}
    ]
    picker_type = PickerType.date
    st.sidebar.markdown("### 📅 Date Range Selection")

date_range_result = date_range_picker(
    picker_type=picker_type, start=default_start, end=default_end,
    key=f'trade_{time_granularity.lower()}_range_picker', refresh_buttons=refresh_buttons
)

if date_range_result:
    start_date, end_date = date_range_result
    start_date = pd.to_datetime(start_date)
    end_date = pd.to_datetime(end_date)
    if time_granularity == "Daily": end_date += pd.Timedelta(days=1)
else:
    start_date, end_date = pd.to_datetime(default_start), pd.to_datetime(default_end)
    if time_granularity == "Daily": end_date += pd.Timedelta(days=1)

if time_granularity == "Hourly":
    st.sidebar.success(f"⏰ Selected: {start_date.strftime('%Y-%m-%d %H:%M')} to {end_date.strftime('%Y-%m-%d %H:%M')}")
else:
    st.sidebar.success(f"📊 Selected: {start_date.strftime('%Y-%m-%d')} to {(end_date - pd.Timedelta(days=1)).strftime('%Y-%m-%d')}")

# --- IMPROVED FILTERS WITH ERROR HANDLING ---
st.sidebar.markdown("### 🏷️ Additional Filters")

# Safe filter creation with fallbacks
def create_safe_filter(column_name, label, default_all=True):
    if column_name in trades_df.columns and not trades_df[column_name].isna().all():
        unique_values = trades_df[column_name].dropna().unique()
        if len(unique_values) > 0:
            default_values = list(unique_values) if default_all else []
            return st.sidebar.multiselect(
                label, 
                options=unique_values, 
                default=default_values
            )
    return []

tag_filter = create_safe_filter('Tag', "Filter by Tag")
product_type_filter = create_safe_filter('ProductType', "Filter by Product Type")
trader_filter = create_safe_filter('Trader', "Filter by Trader")

# Apply filters safely
filtered_trades = trades_df.copy()

# Time filter
filtered_trades = filtered_trades[
    (filtered_trades['Timestamp'] >= start_date) & 
    (filtered_trades['Timestamp'] <= end_date)
]

# Additional filters (only if they have values)
if tag_filter:
    filtered_trades = filtered_trades[filtered_trades['Tag'].isin(tag_filter)]
if product_type_filter:
    filtered_trades = filtered_trades[filtered_trades['ProductType'].isin(product_type_filter)]
if trader_filter:
    filtered_trades = filtered_trades[filtered_trades['Trader'].isin(trader_filter)]

st.sidebar.markdown("---")
st.sidebar.markdown("### 📈 Filter Summary")
st.sidebar.metric("Filtered Trades", f"{len(filtered_trades):,}")
if not filtered_trades.empty and 'Quantity' in filtered_trades.columns:
    total_volume = filtered_trades['Quantity'].sum()
    st.sidebar.metric("Total Volume", f"{total_volume:,.0f}")
else:
    st.sidebar.metric("Total Volume", "0")

# --- DATA REFRESH BUTTON ---
st.sidebar.markdown("---")
if st.sidebar.button("🔄 Refresh Data", use_container_width=True):
    st.cache_data.clear()
    st.rerun()

# --- VIEW FUNCTIONS (Updated with better error handling) ---
def render_kpi_overview():
    st.button("⬅️ Back to Homepage", on_click=set_view, args=['home'])
    st.header("📈 KPI Overview")
    
    if filtered_trades.empty:
        st.warning("No data available for the selected filters.")
        return
    
    total_trades = len(filtered_trades)
    total_quantity = filtered_trades['Quantity'].sum() if 'Quantity' in filtered_trades.columns else 0
    unique_counterparties = filtered_trades['Counterparty'].nunique() if 'Counterparty' in filtered_trades.columns else 0
    avg_price = filtered_trades['Price'].mean() if 'Price' in filtered_trades.columns and not filtered_trades['Price'].isna().all() else 0
    
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Trades Executed", f"{total_trades:,}")
    col2.metric("Total Quantity Traded", f"{total_quantity:,.0f}")
    col3.metric("Unique Counterparties", f"{unique_counterparties}")
    col4.metric("Average Price", f"${avg_price:,.2f}")
    st.markdown("---")
    
    col1, col2 = st.columns([1, 2])
    with col1:
        st.subheader("Trades by Source Tag")
        if 'Tag' in filtered_trades.columns:
            tag_counts = filtered_trades['Tag'].value_counts()
            if not tag_counts.empty:
                fig_donut = go.Figure(data=[go.Pie(labels=tag_counts.index, values=tag_counts.values, hole=.6)])
                fig_donut.update_layout(title_text='Trade Source Distribution', showlegend=True, height=400, margin=dict(l=20, r=20, t=60, b=20))
                st.plotly_chart(fig_donut, use_container_width=True)
            else:
                st.info("No tag data available")
        else:
            st.info("Tag column not found")
            
    with col2:
        st.subheader("Traded Quantity by Product Type")
        if 'ProductType' in filtered_trades.columns and 'Quantity' in filtered_trades.columns:
            qty_by_prod = filtered_trades.groupby('ProductType')['Quantity'].sum().sort_values(ascending=False)
            if not qty_by_prod.empty:
                fig_bar = px.bar(qty_by_prod, x=qty_by_prod.index, y=qty_by_prod.values, 
                               labels={'x': 'Product Type', 'y': 'Total Quantity'}, 
                               color=qty_by_prod.index, text_auto='.2s')
                fig_bar.update_layout(title_text='Volume Breakdown', showlegend=False, height=400)
                st.plotly_chart(fig_bar, use_container_width=True)
            else:
                st.info("No product type data available")
        else:
            st.info("Required columns not found")

def render_data_quality_view():
    st.button("⬅️ Back to Homepage", on_click=set_view, args=['home'])
    st.header("🚦 Data Quality & Validation")
    st.markdown("Analyze the completeness and structure of the trade data.")
    
    if filtered_trades.empty:
        st.warning("No data available for the selected filters.")
        return
    
    col1, col2 = st.columns([2, 1])
    with col1:
        st.subheader("Trade Data Hierarchy")
        required_cols = ['Tag', 'ProductType', 'Trader', 'Quantity']
        if all(col in filtered_trades.columns for col in required_cols):
            fig_treemap = px.treemap(filtered_trades, 
                                   path=[px.Constant("All Trades"), 'Tag', 'ProductType', 'Trader'], 
                                   values='Quantity', 
                                   title="Hierarchical View of Trade Quantity")
            st.plotly_chart(fig_treemap, use_container_width=True)
        else:
            st.info("Missing required columns for treemap visualization")
            
    with col2:
        st.subheader("Data Completeness")
        
        # Check for N/A values in Side column
        if 'Side' in filtered_trades.columns:
            na_sides = filtered_trades[filtered_trades['Side'].isin(['N/A', '', None])]
            side_pct = len(na_sides)/len(filtered_trades)*100 if len(filtered_trades) > 0 else 0
            st.metric("Trades with 'N/A' Side", f"{len(na_sides)} ({side_pct:.1f}%)")
        
        # Check for N/A values in Exchange column
        if 'Exchange' in filtered_trades.columns:
            na_exchange = filtered_trades[filtered_trades['Exchange'].isin(['N/A', '', None])]
            exchange_pct = len(na_exchange)/len(filtered_trades)*100 if len(filtered_trades) > 0 else 0
            st.metric("Trades with 'N/A' Exchange", f"{len(na_exchange)} ({exchange_pct:.1f}%)")
        
        # Show problematic trades
        if 'Side' in filtered_trades.columns:
            na_sides = filtered_trades[filtered_trades['Side'].isin(['N/A', '', None])]
            if not na_sides.empty:
                st.markdown("**Trades flagged for review (N/A Side):**")
                display_cols = ['Timestamp', 'TradeID', 'ProductType', 'Trader']
                available_cols = [col for col in display_cols if col in na_sides.columns]
                if available_cols:
                    st.dataframe(na_sides[available_cols].head(), use_container_width=True, hide_index=True)

def render_market_insights():
    st.button("⬅️ Back to Homepage", on_click=set_view, args=['home'])
    st.header("📊 Market & Price Insights")
    st.markdown("Analyze price trends and relationships from the executed trades.")
    
    if filtered_trades.empty:
        st.warning("No data available for the selected filters.")
        return
    
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Price Evolution Over Time")
        if all(col in filtered_trades.columns for col in ['Symbol', 'Timestamp', 'Price']):
            top_symbols = filtered_trades['Symbol'].value_counts().nlargest(5).index
            price_plot_df = filtered_trades[filtered_trades['Symbol'].isin(top_symbols)]
            if not price_plot_df.empty:
                fig_line = px.line(price_plot_df.sort_values('Timestamp'), 
                                 x='Timestamp', y='Price', color='Symbol', 
                                 title='Price Trends for Top Symbols', markers=True)
                st.plotly_chart(fig_line, use_container_width=True)
            else:
                st.info("No price trend data available")
        else:
            st.info("Missing required columns for price trends")
            
    with col2:
        st.subheader("Price vs. Quantity by Product Type")
        if all(col in filtered_trades.columns for col in ['Quantity', 'Price', 'ProductType']):
            # Filter out zero/negative quantities for log scale
            scatter_data = filtered_trades[filtered_trades['Quantity'] > 0]
            if not scatter_data.empty:
                fig_scatter = px.scatter(scatter_data, x='Quantity', y='Price', 
                                       color='ProductType', size='Quantity', 
                                       hover_name='TradeID' if 'TradeID' in scatter_data.columns else None,
                                       title='Trade Price vs. Quantity', log_x=True)
                st.plotly_chart(fig_scatter, use_container_width=True)
            else:
                st.info("No valid price/quantity data for scatter plot")
        else:
            st.info("Missing required columns for price analysis")

def render_trade_blotter():
    st.button("⬅️ Back to Homepage", on_click=set_view, args=['home'])
    st.header("📋 Detailed Trade Blotter")
    st.markdown(f"Displaying **{len(filtered_trades)}** trades for the selected criteria.")
    
    if filtered_trades.empty:
        st.warning("No trades match the selected filters.")
        return
    
    # Define display columns and check which ones exist
    preferred_cols = ['Timestamp', 'TradeID', 'Tag', 'ProductType', 'Symbol', 'Side', 
                     'Quantity', 'Price', 'Currency', 'Trader', 'Counterparty']
    display_cols = [col for col in preferred_cols if col in filtered_trades.columns]
    
    if not display_cols:
        st.error("No displayable columns found in the data.")
        return
    
    # Configure columns for better display
    column_config = {}
    if "Timestamp" in display_cols:
        column_config["Timestamp"] = st.column_config.DatetimeColumn("Execution Time", format="YYYY-MM-DD HH:mm")
    if "Quantity" in display_cols:
        column_config["Quantity"] = st.column_config.NumberColumn("Qty", format="%d")
    if "Price" in display_cols:
        column_config["Price"] = st.column_config.NumberColumn("Price", format="$%.3f")
    
    st.dataframe(
        filtered_trades[display_cols], 
        use_container_width=True, 
        hide_index=True,
        column_config=column_config
    )

# --- NEW CODE START ---
def render_validation_logs():
    """
    Renders the new dashboard page for validation log analysis.
    """
    st.button("⬅️ Back to Homepage", on_click=set_view, args=['home'])
    st.header("🔬 Validation Log Analysis Dashboard")
    st.markdown("Visualizing the results from the data ingestion and validation pipeline.")

    logs_df, _ = load_validation_logs()

    if logs_df.empty:
        return # Error message is handled in the loading function

    # --- KPIs ---
    st.markdown("---")
    st.subheader("Overall Run Summary")

    total_success = logs_df[logs_df['status'] == 'SUCCESS'].shape[0]
    total_failure = logs_df[logs_df['status'] == 'FAILURE'].shape[0]
    total_logs = len(logs_df)
    success_rate = (total_success / total_logs * 100) if total_logs > 0 else 0

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Log Entries", f"{total_logs}")
    col2.metric("✅ Successful Steps", f"{total_success}")
    col3.metric("❌ Failed Steps", f"{total_failure}")
    col4.metric("Success Rate", f"{success_rate:.2f}%")
    st.markdown("---")

    # --- VISUALIZATIONS ---
    col1, col2 = st.columns([1, 2])

    with col1:
        st.subheader("Success vs. Failure")
        status_counts = logs_df['status'].value_counts()
        colors = {'SUCCESS': 'mediumseagreen', 'FAILURE': 'indianred'}
        fig_pie = go.Figure(data=[go.Pie(
            labels=status_counts.index,
            values=status_counts.values,
            hole=.6,
            marker_colors=[colors.get(k, 'lightgrey') for k in status_counts.index],
            pull=[0.05 if label == 'FAILURE' else 0 for label in status_counts.index]
        )])
        fig_pie.update_layout(
            title_text='Overall Status Breakdown',
            showlegend=True, height=400,
            margin=dict(l=20, r=20, t=60, b=20)
        )
        st.plotly_chart(fig_pie, use_container_width=True)

    with col2:
        st.subheader("Failures by Rule Category")
        failures_df = logs_df[logs_df['status'] == 'FAILURE']
        category_counts = failures_df['rule_category'].value_counts().sort_values(ascending=True)

        if not category_counts.empty:
            fig_bar = go.Figure(go.Bar(
                y=category_counts.index,
                x=category_counts.values,
                orientation='h',
                marker_color='indianred',
                text=category_counts.values,
                textposition='auto'
            ))
            fig_bar.update_layout(
                title_text='Count of Failures per Category',
                xaxis_title='Number of Failures',
                yaxis_title='Rule Category',
                height=400,
                margin=dict(l=20, r=20, t=60, b=20),
                yaxis=dict(autorange="reversed")
            )
            st.plotly_chart(fig_bar, use_container_width=True)
        else:
            st.success("🎉 No failures recorded!")

    # --- DETAILED FAILURE ANALYSIS ---
    st.markdown("---")
    st.subheader("Detailed Failure Log")
    failures_df = logs_df[logs_df['status'] == 'FAILURE'].copy().sort_values(by='timestamp', ascending=False)

    if failures_df.empty:
        st.success("No failures to display.")
    else:
        # Create user-friendly columns from the 'details' dictionary
        failures_df['Message'] = failures_df['details'].apply(lambda x: x.get('message', ''))
        failures_df['Affected Field'] = failures_df['details'].apply(lambda x: x.get('field', 'N/A'))
        failures_df['Invalid Value'] = failures_df['details'].apply(lambda x: str(x.get('invalid_value', 'N/A')))
        failures_df['Trade ID'] = failures_df['details'].apply(lambda x: x.get('record_identifier', {}).get('tradeid', 'Global'))

        # Filter by rule category
        categories = ['All Categories'] + sorted(failures_df['rule_category'].unique().tolist())
        selected_category = st.selectbox("Filter failures by Rule Category:", options=categories)

        if selected_category != 'All Categories':
            display_df = failures_df[failures_df['rule_category'] == selected_category]
        else:
            display_df = failures_df

        st.dataframe(
            display_df[['timestamp', 'rule_category', 'rule_name', 'Message', 'Trade ID', 'Affected Field', 'Invalid Value']],
            hide_index=True,
            use_container_width=True,
            column_config={
                "timestamp": st.column_config.DatetimeColumn("Timestamp", format="YYYY-MM-DD HH:mm:ss"),
                "rule_category": st.column_config.Column("Category", width="medium"),
                "rule_name": st.column_config.Column("Rule Name", width="medium"),
            }
        )

        st.info("Expand the section below to see the full JSON details for each failure in the filtered view.")
        with st.expander("Show Raw Failure Details (JSON)"):
            st.json(display_df.to_dict(orient='records'))
# --- NEW CODE END ---


def render_home_page():
    st.title("💼 ETRM Business Intelligence Hub")
    st.markdown("Select a widget to explore trade data from your ETRM database.")
    
    total_trades = len(filtered_trades)
    total_volume = filtered_trades['Quantity'].sum() if 'Quantity' in filtered_trades.columns and not filtered_trades.empty else 0
    counterparties = filtered_trades['Counterparty'].nunique() if 'Counterparty' in filtered_trades.columns and not filtered_trades.empty else 0
    
    with st.container(border=True):
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("📊 Total Trades", f"{total_trades:,}")
        col2.metric("💰 Total Volume", f"{total_volume:,.0f}")
        col3.metric("🏢 Counterparties", f"{counterparties}")
        
        if time_granularity == "Hourly": 
            time_span = f"{(end_date - start_date).total_seconds() / 3600:.1f} hours"
        else: 
            time_span = f"{(end_date - start_date).days} days"
        col4.metric("⏰ Time Span", time_span)
    
    st.write("---")
    col1, col2 = st.columns(2)
    with col1:
        with st.container(border=True):
            st.header("📈 KPI Overview")
            st.markdown("High-level metrics on trade counts, total quantity, and counterparties.")
            st.button("Launch KPI View", on_click=set_view, args=['kpi'], use_container_width=True, type="primary")
        st.write("")
        with st.container(border=True):
            st.header("📊 Market & Price Insights")
            st.markdown("Analyze price trends over time and relationships between price and quantity.")
            st.button("Launch Market View", on_click=set_view, args=['insights'], use_container_width=True)
    with col2:
        with st.container(border=True):
            st.header("🚦 Data Quality & Validation")
            st.markdown("A deep-dive into the structure and completeness of the trade data files.")
            st.button("Launch Quality View", on_click=set_view, args=['quality'], use_container_width=True)
        st.write("")
        with st.container(border=True):
            st.header("📋 Trade Blotter")
            st.markdown("View, search, and filter all individual trades captured by the system.")
            st.button("Launch Trade Blotter", on_click=set_view, args=['blotter'], use_container_width=True)

    # --- NEW CODE START ---
    st.write("---")
    with st.container(border=True):
        col1, col2 = st.columns([3, 1])
        with col1:
            st.header("🔬 Validation Log Insights")
            st.markdown("Visualize the results and errors from the data ingestion and validation pipeline. Analyze failure rates, error types, and affected records to improve data quality at the source.")
        with col2:
            st.write("") 
            st.write("")
            st.button("Launch Log Viewer", on_click=set_view, args=['validation'], use_container_width=True, type="primary")
    # --- NEW CODE END ---

# --- MAIN ROUTER ---
if st.session_state.active_view == 'home': 
    render_home_page()
elif st.session_state.active_view == 'kpi': 
    render_kpi_overview()
elif st.session_state.active_view == 'quality': 
    render_data_quality_view()
elif st.session_state.active_view == 'insights': 
    render_market_insights()
elif st.session_state.active_view == 'blotter': 
    render_trade_blotter()
# --- NEW CODE START ---
elif st.session_state.active_view == 'validation': 
    render_validation_logs()
# --- NEW CODE END ---